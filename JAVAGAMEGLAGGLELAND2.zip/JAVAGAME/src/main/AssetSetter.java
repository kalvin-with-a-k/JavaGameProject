package main;

import entity.NPC_Sensei_Wu;
import objects.OBJ_boots;
import objects.OBJ_chest;
import objects.OBJ_door;
import objects.OBJ_key;

public class AssetSetter {

	GamePanel gp;
	
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	public void setObject() {
		
		
	}
	public void setNPC() {
		
		gp.npc[0] = new NPC_Sensei_Wu(gp);
		gp.npc[0].worldX = gp.tileSize*29;
		gp.npc[0].worldY = gp.tileSize*29;
	}
}
