package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {

	GamePanel gp;
    public boolean upPress, downPress, leftPress, rightPress, enterPress;
    public boolean toggleDebug = false; // DEBUG
  
    
    public KeyHandler(GamePanel gp) {
    	this.gp = gp;
    }
    
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode(); 
        
        // TITLE STATE
        if(gp.gameState == gp.titleState) {
        	
        	if(gp.ui.titleScreenState == 0) {
        		
        		if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
                    gp.ui.commandNum--;
                    if(gp.ui.commandNum < 0) {
                    	gp.ui.commandNum = 2;
                    }
                }
                if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
                    gp.ui.commandNum++;
                    if(gp.ui.commandNum > 2) {
                    	gp.ui.commandNum = 0;
                    }
                }
                if(code == KeyEvent.VK_ENTER) {
                	if(gp.ui.commandNum == 0) {
                		gp.ui.titleScreenState = 1;
                		// gp.playMusic(4);		<-	TO ADD DIFFERENT SONG DURING CHARACTER CUSTOMIZATION
                	}
                	if(gp.ui.commandNum == 1) {
                		// ADD LATER
                	}
                	if(gp.ui.commandNum == 2) {
                		System.exit(0);
                	}
                }
        	}
        	else if(gp.ui.titleScreenState == 1) {
        		
        		if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
                    gp.ui.commandNum--;
                    if(gp.ui.commandNum < 0) {
                    	gp.ui.commandNum = 3;
                    }
                }
                if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
                    gp.ui.commandNum++;
                    if(gp.ui.commandNum > 3) {
                    	gp.ui.commandNum = 0;
                    }
                }
                if(code == KeyEvent.VK_ENTER) {
                	if(gp.ui.commandNum == 0) {
                		System.out.println("RPG GBP! Blonde kid, super talented, has a knack for cheese.");
                		gp.gameState = gp.playState;
                		gp.playMusic(4);
                	}
                	if(gp.ui.commandNum == 1) {
                		System.out.println("Rika is a bizarre ghost whose existence defies the boundaries between life and death. She can teleport, is technically immortal, and is an idiot.");
                		gp.gameState = gp.playState;
                		gp.playMusic(4);
                	}
                	if(gp.ui.commandNum == 2) {
                    	System.out.println("Big red-haired muscle freak. Kind guy, though.");
                    	gp.gameState = gp.playState;
                    	gp.playMusic(4);
                	}
                	if(gp.ui.commandNum == 3) {
                		gp.ui.titleScreenState = 0;
                	}
                }
        	}
        	
      }
        
        if(gp.gameState == gp.playState) {
        	
        	if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
                upPress = true;
            }
            if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
                downPress = true;
            }
            if (code == KeyEvent.VK_A || code == 37) {  // A or Left arrow
                leftPress = true;
            }
            if (code == KeyEvent.VK_D || code == 39) {  // D or Right arrow
                rightPress = true;
            }
            
            if (code == KeyEvent.VK_P) {  // Pause
            	gp.gameState = gp.pauseState;
            }
            
            if (code == KeyEvent.VK_ENTER) {  // Open Dialogue 
            	enterPress = true;
            }
        
            // DEBUG
            if(code == KeyEvent.VK_T) {
        	toggleDebug = !toggleDebug;
            }
        }
    
    
        // PAUSE STATE
        else if(gp.gameState == gp.pauseState) {
        	if (code == KeyEvent.VK_P) {  // Unpause
            	gp.gameState = gp.playState;
        	}
        }
    
        // DIALOGUE STATE
        else if(gp.gameState == gp.dialogueState) {
        	if(code == KeyEvent.VK_ENTER) {
        		gp.gameState = gp.playState;
        	}
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();  

        if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
            upPress = false;
        }
        if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
            downPress = false;
        }
        if (code == KeyEvent.VK_A || code == 37) {  // A or Left arrow
            leftPress = false;
        }
        if (code == KeyEvent.VK_D || code == 39) {  // D or Right arrow
            rightPress = false;
        }
    }
}
