package tile;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.UtilityToolbox;

public class TileManager {

	GamePanel gp;
	public Tile[] tile;
	public int mapTileNum[][];
	
	public TileManager(GamePanel gp) {
		this.gp = gp;
		tile = new Tile[70];
		mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
		getTileImage();
		loadMap("/maps/worldmap.txt");
	}
	
	public void getTileImage() {
			
			setUp(0, "grassTop1", false);
			setUp(1, "grassTop1", false);
			setUp(2, "grassTop1", false);
			setUp(3, "grassTop1", false);
			setUp(4, "grassTop1", false);
			setUp(5, "grassTop1", false);
			setUp(6, "grassTop1", false);
			setUp(7, "grassTop1", false);
			setUp(8, "grassTop1", false);
			setUp(9, "grassTop1", false);
			// 0 to 9 won't be used so these are placeholders to avoid null pointer error
			
			setUp(10, "grassTop1", false);
			setUp(11, "grassTop2", false);
			setUp(12, "grassTop3", false);
			setUp(13, "grassTop4", false);
			setUp(14, "grassTop5", false);
			setUp(15, "grassMid1", false);
			setUp(16, "grassMid2", false);
			setUp(17, "grassMid3", false);
			setUp(18, "grassMid4", false);
			setUp(19, "grassMid5", false);
			setUp(20, "grassBot1", false);
			setUp(21, "grassBot2", false);
			setUp(22, "grassBot3", false);
			setUp(23, "grassBot4", false);
			setUp(24, "grassBot5", false);
			
			setUp(25, "earthTop1", false);
			setUp(26, "earthTop2", false);
			setUp(27, "earthTop3", false);
			setUp(28, "earthMid1", false);
			setUp(29, "earthMid2", false);
			setUp(30, "earthMid3", false);
			setUp(31, "earthBot1", false);
			setUp(32, "earthBot2", false);
			setUp(33, "earthBot3", false);
			
			setUp(34, "sand", false);
			setUp(35, "tree", true);
			setUp(36, "wall", true);
			setUp(37, "water", true);		
	}
	
	public void setUp(int index, String imageName, boolean collision) {
		UtilityToolbox uTool = new UtilityToolbox();
		
		try {
			tile[index] = new Tile();
			tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/" + imageName + ".png"));
			tile[index].image = uTool.scaledImage(tile[index].image, gp.tileSize, gp.tileSize);
			tile[index].collision = collision;
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void loadMap(String filePath) {
		
		try {
			InputStream is = getClass().getResourceAsStream(filePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while(col < gp.maxWorldCol && row < gp.maxWorldRow) {
				
				String line = br.readLine();
				
				while(col < gp.maxWorldCol) {
					String numbers[] = line.split(" ");
					
					int num = Integer.parseInt(numbers[col]);
					
					mapTileNum[col][row] = num;
					col++;
				}
				if(col == gp.maxWorldCol) {
					col = 0;
					row++;
				}
			}
			br.close();
			
			
		}catch(Exception e) {
			
		}
		
	}
	public void draw(Graphics2D g2) {
		
		int worldCol = 0;
		int worldRow = 0; 
		
		while(worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow) {
			
			int tileNum = mapTileNum[worldCol][worldRow];
			
			int worldX = worldCol * gp.tileSize;
			int worldY = worldRow * gp.tileSize;
			int screenX = worldX - gp.player.worldX + gp.player.screenX;
			int screenY = worldY - gp.player.worldY + gp.player.screenY;
			
			if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && 
			   worldX - gp.tileSize < gp.player.worldX + gp.player.screenX && 
			   worldY + gp.tileSize > gp.player.worldY - gp.player.screenY && 
			   worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
				g2.drawImage(tile[tileNum].image, screenX, screenY, null);
			}
			
			worldCol++;
			
			if(worldCol == gp.maxWorldCol) {
				worldCol = 0;
				worldRow++;
			}
		}
	}
}
