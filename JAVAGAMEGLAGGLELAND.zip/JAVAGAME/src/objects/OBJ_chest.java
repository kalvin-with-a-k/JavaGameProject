package objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class OBJ_chest extends SuperObject{
 
	GamePanel gp;
	
	public OBJ_chest(GamePanel gp) {
		
		this.gp = gp;
		
		name = "Chest";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/chest.png"));
			image = uTool.scaledImage(image,  gp.tileSize, gp.tileSize);
			
		}catch(IOException e) {
			e.printStackTrace();		
		}
	}
}
