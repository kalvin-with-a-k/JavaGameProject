package monster;

import java.util.Random;

import entity.Entity;
import main.GamePanel;

public class MON_GreenSlime extends Entity {
	
	GamePanel gp;
	
	public MON_GreenSlime(GamePanel gp) {
		super(gp);
		
		this.gp = gp;
		
		type = 2;
		name = "Green Slime";
		speed = 1;
		maxHealth = 10;
		health = maxHealth;
		
		hitboxArea.x = 3;
		hitboxArea.y = 18;
		hitboxArea.width = 42;
		hitboxArea.height = 30;
		solidAreaDefaultX = hitboxArea.x;
		solidAreaDefaultY = hitboxArea.y;
		
		getImage();
	}
	
	public void getImage() {
		up1 = setUp("/monsters/greenSlimeDown1", gp.tileSize, gp.tileSize);
		up2 = setUp("/monsters/greenSlimeDown2", gp.tileSize, gp.tileSize);
		down1 = setUp("/monsters/greenSlimeDown1", gp.tileSize, gp.tileSize);
		down2 =  setUp("/monsters/greenSlimeDown2", gp.tileSize, gp.tileSize);
		left1 = setUp("/monsters/greenSlimeDown1", gp.tileSize, gp.tileSize);
		left2 = setUp("/monsters/greenSlimeDown2", gp.tileSize, gp.tileSize);
		right1 = setUp("/monsters/greenSlimeDown1", gp.tileSize, gp.tileSize);
		right2 = setUp("/monsters/greenSlimeDown2", gp.tileSize, gp.tileSize);
	}
	
	public void setAction() {
		
		movementInterval++;
		
		if(movementInterval == 110) {
		
		Random random = new Random();
		int i = random.nextInt(100)+1; // RNG 1-100
		
		if(i <= 25) {
			direction = "up";
		}
		if(i > 25 && i <= 50) {
			direction = "down";
		}
		if(i > 50 && i <= 75) {
			direction = "left";
		}
		if(i > 75 && i <= 100) {
			direction = "right";
		}
		movementInterval = 0;
		}
	}
	public void damageReaction() {
		
		movementInterval= 0;
		direction = gp.player.direction;
		speed = 2;
	}
	
	
	
}
