package objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_Heart extends Entity{
	
	public OBJ_Heart(GamePanel gp) {
		
		super(gp);
		
		name = "Boots";
		image = setUp("/objects/fullHeart", gp.tileSize, gp.tileSize);
		image2  = setUp("/objects/halfHeart", gp.tileSize, gp.tileSize);
		image3  = setUp("/objects/blankHeart", gp.tileSize, gp.tileSize);
	}
}