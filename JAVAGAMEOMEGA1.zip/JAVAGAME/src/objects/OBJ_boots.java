package objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_boots extends Entity{
	
	public OBJ_boots(GamePanel gp) {
		
		super(gp);
		
		name = "Boots";
		down1  = setUp("/objects/boot", gp.tileSize, gp.tileSize);
	}
}

