package objects;

import entity.Entity;
import entity.Projectile;
import main.GamePanel;

public class OBJ_Fireball extends Projectile {

	GamePanel gp;
	
	public OBJ_Fireball(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		name = "Fireball";
		speed = 6;
		maxHealth = 80;
		health = maxHealth;
		attack = 3;
		manaCost = 1;
		alive = false;
		getImage();

	}

	public void getImage() {
		up1 = setUp("/projectiles/fireballUp1", gp.tileSize, gp.tileSize);
		up2 = setUp("/projectiles/fireballUp2", gp.tileSize, gp.tileSize);
		down1 = setUp("/projectiles/fireballDown1", gp.tileSize, gp.tileSize);
		down2 = setUp("/projectiles/fireballDown2", gp.tileSize, gp.tileSize);
		left1 = setUp("/projectiles/fireballLeft1", gp.tileSize, gp.tileSize);
		left2 = setUp("/projectiles/fireballLeft2", gp.tileSize, gp.tileSize);
		right1 = setUp("/projectiles/fireballRight1", gp.tileSize, gp.tileSize);
		right2 = setUp("/projectiles/fireballRight2", gp.tileSize, gp.tileSize);
	}
	
	public boolean haveEnoughMana(Entity user) {
		
		boolean haveEnoughMana = false;
		if(user.mana >= manaCost) {
			haveEnoughMana = true;
		}
		return haveEnoughMana;
	}
	
	public void subtractMana(Entity user) {
		user.mana -= manaCost;
	}
}








