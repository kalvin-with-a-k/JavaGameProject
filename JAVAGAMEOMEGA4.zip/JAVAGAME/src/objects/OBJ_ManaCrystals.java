package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_ManaCrystals extends Entity{

	GamePanel gp;
	
	public OBJ_ManaCrystals(GamePanel gp) {
		super(gp);
		this.gp = gp;
		
		name = "Mana Crystal";
		image = setUp("/objects/emptyManaCrystal", gp.tileSize, gp.tileSize);
		image2 = setUp("/objects/fullManaCrystal", gp.tileSize, gp.tileSize);
	}

}
