package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Axe extends Entity{
	
	public OBJ_Axe(GamePanel gp) {
		
		super(gp);
		
		type = type_axe;
		name = "Basic Axe";
		down1  = setUp("/objects/basicAxe", gp.tileSize, gp.tileSize);
		
		attackValue = 3;
		attackHitbox.width = 30;
		attackHitbox.height = 30;
		description = "[" + name + "]\n A stolen axe from a nearby shed.";
	}
}
