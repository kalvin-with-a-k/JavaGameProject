package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Uncommon_Shield extends Entity{
	
	public OBJ_Uncommon_Shield(GamePanel gp) {
		
		super(gp);
		
		type = type_shield;
		name = "Basic Shield";
		down1  = setUp("/objects/uncommonShield", gp.tileSize, gp.tileSize);
		
		defenseValue = 2;
		description = "[" + name + "]\nA better shield than a basic one.";
	}
}
