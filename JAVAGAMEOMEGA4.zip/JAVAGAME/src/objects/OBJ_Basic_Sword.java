package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Basic_Sword extends Entity{
	
	public OBJ_Basic_Sword(GamePanel gp) {
		
		super(gp);
		
		type = type_sword;
		name = "Basic Sword";
		down1  = setUp("/objects/basicSword", gp.tileSize, gp.tileSize);
		
		attackValue = 3;
		attackHitbox.width = 34;
		attackHitbox.height = 34;
		description = "[" + name + "]\n Basic Sword. Not very sharp.";
	}
}

