package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Health_Potion extends Entity{
	
	GamePanel gp;
	int value = 3;
	
	public OBJ_Health_Potion(GamePanel gp) {	

		super(gp);
		this.gp = gp;
		
		type = type_consumable;
		name = "Health Potion";
		down1  = setUp("/objects/healthPotion", gp.tileSize, gp.tileSize);
		description = "[" + name + "]\n Yummy life juice. heals " + value + "hp.";
	}
	
	public void use(Entity entity) {
		
		gp.gameState = gp.dialogueState;
		gp.ui.currentDialogue = "You drink the " + name + "!\n"
							  + "Your health recovers by " + value + ".";
		entity.health += value;
		if(gp.player.health > gp.player.maxHealth) {
			gp.player.health = gp.player.maxHealth;
		}
		gp.playSFX(8);
	}
}

