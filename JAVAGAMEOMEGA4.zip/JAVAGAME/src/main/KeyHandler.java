package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {

	GamePanel gp;
    public boolean upPress, downPress, leftPress, rightPress, enterPress, ePress;
    public boolean toggleDebug = false; // DEBUG
  
    
    public KeyHandler(GamePanel gp) {
    	this.gp = gp;
    }
    
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    	
        int code = e.getKeyCode(); 
        
        if(gp.gameState == gp.titleState) {
        	titleState(code);
        }
        else if(gp.gameState == gp.playState) {
        	playState(code);
        }
        else if(gp.gameState == gp.pauseState) {
        	pauseState(code);
        }
        else if(gp.gameState == gp.dialogueState) {
        	dialogueState(code);
        }
        else if(gp.gameState == gp.characterState) {
        	characterState(code);
        }
    }
        
    public void titleState(int code) {
    	
    	if(gp.ui.titleScreenState == 0) {
    		
    		if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
    			gp.ui.commandNum--;
    			if(gp.ui.commandNum < 0) {
    				gp.ui.commandNum = 2;
    			}
    		}
    		if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
    			gp.ui.commandNum++;
    			if(gp.ui.commandNum > 2) {
    				gp.ui.commandNum = 0;
    			}
    		}
    		if(code == KeyEvent.VK_ENTER) {
    			if(gp.ui.commandNum == 0) {
    				gp.ui.titleScreenState = 1;
    				// gp.playMusic(4);		<-	TO ADD DIFFERENT SONG DURING CHARACTER CUSTOMIZATION
    			}
    			if(gp.ui.commandNum == 1) {
    				// ADD LATER
    			}
    			if(gp.ui.commandNum == 2) {
    				System.exit(0);
    			}
    		}
    	}
        else if(gp.ui.titleScreenState == 1) {
    		
    		if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
                gp.ui.commandNum--;
                if(gp.ui.commandNum < 0) {
                	gp.ui.commandNum = 3;
                }
            }
            if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
                gp.ui.commandNum++;
                if(gp.ui.commandNum > 3) {
                	gp.ui.commandNum = 0;
                }
            }
            if(code == KeyEvent.VK_ENTER) {
            	if(gp.ui.commandNum == 0) {
            		System.out.println("RPG GBP! Blonde kid, super talented, has a knack for cheese.");
            		gp.gameState = gp.playState;
            		gp.playMusic(4);
            	}
            	if(gp.ui.commandNum == 1) {
            		System.out.println("Rika is a bizarre ghost whose existence defies the boundaries between life and death. She can teleport, is technically immortal, and is an idiot.");
            		gp.gameState = gp.playState;
            		gp.playMusic(4);
            	}
            	if(gp.ui.commandNum == 2) {
                	System.out.println("Big red-haired muscle freak. Kind guy, though.");
                	gp.gameState = gp.playState;
                	gp.playMusic(4);
            	}
            	if(gp.ui.commandNum == 3) {
            		gp.ui.titleScreenState = 0;
            	}
            }
    	}
    	gp.ui.commandNum = 0;
    }
    
    public void playState(int code) {
    	
    	if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
            upPress = true;
        }
        if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
            downPress = true;
        }
        if (code == KeyEvent.VK_A || code == 37) {  // A or Left arrow
            leftPress = true;
        }
        if (code == KeyEvent.VK_D || code == 39) {  // D or Right arrow
            rightPress = true;
        }
        
        if (code == KeyEvent.VK_P) {  // Pause
        	gp.gameState = gp.pauseState;
        }
        
        if (code == KeyEvent.VK_ENTER) {  // Open Dialogue or Attack
        	enterPress = true;
        }
        
        if (code == KeyEvent.VK_E || code == 69) {  // Projectile Attack
        	ePress = true;
        }
        
        if (code == KeyEvent.VK_C) { 
        	gp.gameState = gp.characterState;
        }
    
        // DEBUG
        if(code == KeyEvent.VK_T) {
    	toggleDebug = !toggleDebug;
        }
    }
    
    public void pauseState(int code) {
    	if (code == KeyEvent.VK_P) {  // Unpause
    		gp.gameState = gp.playState;
    	}
    }
    
    public void dialogueState(int code) {
    	if(code == KeyEvent.VK_ENTER) {
    		gp.gameState = gp.playState;
    	}
    }
    
    public void characterState(int code) {
        
    	if (code == KeyEvent.VK_C) {
            gp.gameState = gp.playState; // Exit character screen
        }
        if (code == KeyEvent.VK_1) {
            gp.ui.characterScreenState = (gp.ui.characterScreenState == 0) ? 1 : 0; // Toggle between stat pages (0 → 1, 1 → 0)
        }
        if (code == KeyEvent.VK_ENTER) {
            gp.player.selectItem();
            enterPress = false;
        }
        if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
        	if(gp.ui.slotRow != 0)
            gp.ui.slotRow--;
        }
        if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
        	if(gp.ui.slotRow != 3)
            gp.ui.slotRow++;
        }
        if (code == KeyEvent.VK_A || code == 37) {  // A or Left arrow
        	if(gp.ui.slotCol != 0)
            gp.ui.slotCol--;
        }
        if (code == KeyEvent.VK_D || code == 39) {  // D or Right arrow
        	if(gp.ui.slotCol != 4)
            gp.ui.slotCol++;
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();  

        if (code == KeyEvent.VK_W || code == 38) {  // W or Up arrow
            upPress = false;
        }
        if (code == KeyEvent.VK_S || code == 40) {  // S or Down arrow
            downPress = false;
        }
        if (code == KeyEvent.VK_A || code == 37) {  // A or Left arrow
            leftPress = false;
        }
        if (code == KeyEvent.VK_D || code == 39) {  // D or Right arrow
            rightPress = false;
        }
        if (code == KeyEvent.VK_E || code == 69) {  // Projectile Attack
        	ePress = false;
        }
    }
}
