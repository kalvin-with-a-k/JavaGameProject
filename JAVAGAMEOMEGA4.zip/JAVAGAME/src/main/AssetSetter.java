package main;

import entity.NPC_Sensei_Wu;
import monster.MON_GreenSlime;
import objects.OBJ_Axe;
import objects.OBJ_Health_Potion;
import objects.OBJ_Uncommon_Shield;
import objects.OBJ_boots;
import objects.OBJ_chest;
import objects.OBJ_door;
import objects.OBJ_key;
import entity.Entity;

public class AssetSetter {

	GamePanel gp;
	
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	public void setObject() {
		
		int i = 0;
		
		gp.obj[i] = new OBJ_key(gp);
		gp.obj[i].worldX = gp.tileSize*22;
		gp.obj[i].worldY = gp.tileSize*22;
		i++;
		gp.obj[i] = new OBJ_key(gp);
		gp.obj[i].worldX = gp.tileSize*21;
		gp.obj[i].worldY = gp.tileSize*21;
		i++;
		gp.obj[i] = new OBJ_key(gp);
		gp.obj[i].worldX = gp.tileSize*20;
		gp.obj[i].worldY = gp.tileSize*20;
		i++;
		gp.obj[i] = new OBJ_Axe(gp);
		gp.obj[i].worldX = gp.tileSize*27;
		gp.obj[i].worldY = gp.tileSize*27;
		i++;
		gp.obj[i] = new OBJ_Uncommon_Shield(gp);
		gp.obj[i].worldX = gp.tileSize*28;
		gp.obj[i].worldY = gp.tileSize*27;
		i++;
		gp.obj[i] = new OBJ_Health_Potion(gp);
		gp.obj[i].worldX = gp.tileSize*26;
		gp.obj[i].worldY = gp.tileSize*26;
	}
	public void setNPC() {
		
		gp.npc[0] = new NPC_Sensei_Wu(gp);
		gp.npc[0].worldX = gp.tileSize*29;
		gp.npc[0].worldY = gp.tileSize*29;
	}
	public void setMonster() {
		
		int i = 0;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldX = gp.tileSize*30;
		gp.monster[i].worldY = gp.tileSize*26;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldX = gp.tileSize*32;
		gp.monster[i].worldY = gp.tileSize*23;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldX = gp.tileSize*34;
		gp.monster[i].worldY = gp.tileSize*27;
		i++;
		gp.monster[i] = new MON_GreenSlime(gp);
		gp.monster[i].worldX = gp.tileSize*35;
		gp.monster[i].worldY = gp.tileSize*28;
		i++;
	}
}
