package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;
import objects.OBJ_key;
import objects.OBJ_boots;

public class UI {

	GamePanel gp;
	Font serif_40, serif_80Win;
	BufferedImage keyImage, bootImage;
	public boolean msgOn = false;
	public String message = "";
	int msgCounter = 0;
	public boolean gameFinished = false;
	double playTime;
	DecimalFormat dFormat = new DecimalFormat("#0.00");
	
	public UI(GamePanel gp) {
		this.gp = gp;
		
		serif_40 = new Font("Serif", Font.BOLD, 40);
		serif_80Win = new Font("Serif", Font.BOLD, 80);
		OBJ_key Key = new OBJ_key();
		keyImage = Key.image;
		OBJ_boots Boots = new OBJ_boots();
		bootImage = Boots.image;
	}
	
	public void showMessage(String text) {
		
		message = text;
		msgOn = true;
	}
	
	public void draw(Graphics2D g2) {
		
		if(gameFinished == true) {
			
			String text;
			int textLength;
			int x;
			int y;
			
			g2.setFont(serif_40);
			g2.setColor(Color.white);	
			
			text = "YOU FOUND GOLDEN DOUBLOONS!!!!";
			textLength = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
			x = gp.screenWidth/2 - textLength/2;
			y = gp.screenHeight/2 - (gp.tileSize*3);
			g2.drawString(text, x,  y);
			
			text = "Your Time was: " + dFormat.format(playTime) + " seconds!";
			textLength = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
			x = gp.screenWidth/2 - textLength/2;
			y = gp.screenHeight/2 - (gp.tileSize*2);
			g2.drawString(text, x,  y);
			
			
			g2.setFont(serif_80Win);
			g2.setColor(Color.yellow);
			
			text = "CONGRATS LOSER!!!!";
			textLength = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
			x = gp.screenWidth/2 - textLength/2;
			y = gp.screenHeight/2 + (gp.tileSize*2);
			g2.drawString(text, x,  y);
			
		    gp.gameThread = null;
		       
		}
		else {
			g2.setFont(serif_40);
			g2.setColor(Color.white);
			
			g2.drawImage(keyImage, gp.tileSize/2, gp.tileSize/2, gp.tileSize, gp.tileSize, null);
			g2.drawString("x = " + gp.player.hasKey, 125, 90);
			g2.drawImage(bootImage, gp.tileSize/2, gp.tileSize/2 + gp.tileSize, gp.tileSize, gp.tileSize, null);
			g2.drawString("x = " + gp.player.hasBoots, 125, 170);
			
			// TIME
			playTime +=(double)1/60;
			g2.drawString("Time: " + dFormat.format(playTime), gp.tileSize*13, 90);
			
			
			// MESSAGE
			if(msgOn == true) {
				g2.setFont(g2.getFont().deriveFont(35F));
				g2.drawString(message, gp.tileSize*6, gp.tileSize*2);
				
				msgCounter++;
				
					if(msgCounter > 135) {
						msgCounter = 0;
						msgOn = false;
				}
			}
		}
	}
}
