/**
 * 
 */
/**
 * 
 */
module JAVAGAME {
	requires java.desktop;
}