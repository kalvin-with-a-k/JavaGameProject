package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Basic_Shield extends Entity{
	
	public OBJ_Basic_Shield(GamePanel gp) {
		
		super(gp);
		
		type = type_shield;
		name = "Basic Shield";
		down1  = setUp("/objects/basicShield", gp.tileSize, gp.tileSize);
		
		defenseValue = 1;
		description = "[" + name + "]\nDecent shield. It's scratched\nthough...";
	}
}
