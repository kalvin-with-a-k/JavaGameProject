package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import objects.OBJ_Heart;
import entity.Entity;

public class UI {

	GamePanel gp;
	Graphics2D g2;
	Font serif_35, serif_80Win;
	BufferedImage fullHeart, halfHeart, blankHeart, keyimage, bootImage;
	public boolean msgOn = false;
	ArrayList<String> message = new ArrayList<>();
	ArrayList<Integer>messageCounter = new ArrayList<>();
	public boolean gameFinished = false;
	public String currentDialogue = "";
	public int commandNum = 0;
	public int titleScreenState = 0;	// 0: Title Screen, 1: Character Change screens, etc
	public int characterScreenState = 0; // Pages of Stats
	public int slotCol = 0;
	public int slotRow = 0;
	
	public UI(GamePanel gp) {
		this.gp = gp;
		
		serif_35 = new Font("Serif", Font.BOLD, 35);
		serif_80Win = new Font("Serif", Font.BOLD, 80);
		
		// CREATE HUD OBJECTS
		Entity heart = new OBJ_Heart(gp);
		fullHeart = heart.image;
		halfHeart = heart.image2;
		blankHeart = heart.image3;
	}
	
	public void addMessage(String text) {
		
		message.add(text);
		messageCounter.add(0);
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		
		g2.setFont(serif_35);
		g2.setColor(Color.white);
		
		if(gp.gameState == gp.titleState) {
			drawTitleScreen();
		}
		if(gp.gameState == gp.playState) {
			drawPlayerHealth();
			drawMessage();
		}
		if(gp.gameState == gp.pauseState) {
			drawPlayerHealth();
			drawPauseScreen();
		}
		if(gp.gameState == gp.dialogueState) {
			drawPlayerHealth();
			drawDialogueScreen();
		}
		if (gp.gameState == gp.characterState) {
			drawCharacterScreen();
			drawInventory();
		}
	} 
	
	public void drawPlayerHealth() {
		
		int x = gp.tileSize/2;
		int y = gp.tileSize/2;
		int i = 0;
		
		// BLANK HEARTS
		while(i < gp.player.maxHealth/2) {
			g2.drawImage(blankHeart, x, y, null);
			i++;
			x += gp.tileSize;
		}
		
		// RESET
		x = gp.tileSize/2;
		y = gp.tileSize/2;
		i = 0;
		
		// CURRENT HEALTH
		while(i < gp.player.health) {
			g2.drawImage(halfHeart, x, y, null);
			i++;
			if(i < gp.player.health) {
				g2.drawImage(fullHeart, x, y, null);
			}
			i++;
			x += gp.tileSize;
		}
	}
	
	public void drawMessage() {
		
		int messageX = gp.tileSize;
		int messageY = gp.tileSize*3;
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 32F));
		
		for(int i = 0; i < message.size(); i++) {
			if(message.get(i) != null) {
				g2.setColor(Color.white);
				g2.drawString(message.get(i), messageX, messageY);
				
				int counter = messageCounter.get(i) + 1; 
				messageCounter.set(i, counter);
				messageY += 50;
				
				if(messageCounter.get(i) > 180) {
					message.remove(i);
					messageCounter.remove(i);
				}
			}
		}
	}
	
	public void drawTitleScreen() {
		
		if(titleScreenState == 0) {

			// IF I WANT TO CHANGE TITLE BG COLOR
			// g2.setColor(new Color(50, 100, 50));
			// g2.fillRect(0,  0, gp.screenWidth,  gp.screenHeight);
			
			//TITLE NAME
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,98F));
			String text = "Glaggle Land";
			int x = xForCenteredText(text);
			int y = gp.tileSize*2;
			
			// SHADOW
			g2.setColor(new Color(90, 90, 90));
			g2.drawString(text, x+5, y+5);
			
			// MAIN TEXT COLOR
			g2.setColor(Color.white);
			g2.drawString(text, x, y);
			
			// MAKE PLAYER AND SENSEI WU SIDE BY SIDE
			x = gp.screenWidth/2 - (gp.tileSize*2);
			y += gp.tileSize;
			g2.drawImage(gp.npc[0].left1, x, y, gp.tileSize*2, gp.tileSize*2, null);
			
			x = gp.screenWidth/2;
			g2.drawImage(gp.player.right1, x, y, gp.tileSize*2, gp.tileSize*2, null);
			
			// MENU
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,50F));
			
			text = "NEW GAME";
			x = xForCenteredText(text);
		    y += gp.tileSize*3;
		    g2.drawString(text,  x, y);
		    if(commandNum == 0) {
		    	g2.drawString(">", x - gp.tileSize/2 - 10, y);
		    }
		    
		    text = "LOAD GAME";
			x = xForCenteredText(text);
		    y += gp.tileSize;
		    g2.drawString(text,  x, y);
		    if(commandNum == 1) {
		    	g2.drawString(">", x - gp.tileSize/2 - 10, y);
		    }
		    
		    text = "QUIT";
			x = xForCenteredText(text);
		    y += gp.tileSize;
		    g2.drawString(text,  x, y);
		    if(commandNum == 2) {
		    	g2.drawString(">", x - gp.tileSize/2 - 10, y);
		    }
		}
		else if(titleScreenState == 1) {
			
			g2.setColor(Color.white);
			g2.setFont(g2.getFont().deriveFont(42F));
			
			String text = "Select your character!";
			int x = xForCenteredText(text);
			int y = gp.tileSize*2;
			g2.drawString(text,  x,  y);
			
			text = "RPG GBP";
			x = xForCenteredText(text);
			y += gp.tileSize*2;
			g2.drawString(text,  x,  y);
			if(commandNum == 0) {
				g2.drawString(">", x - gp.tileSize, y);
			}
			
			text = "Rika";
			x = xForCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text,  x,  y);
			if(commandNum == 1) {
				g2.drawString(">", x - gp.tileSize, y);
			}
			
			text = "Red";
			x = xForCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text,  x,  y);
			if(commandNum == 2) {
				g2.drawString(">", x - gp.tileSize, y);
			}
			text = "BACK";
			x = xForCenteredText(text);
			y += gp.tileSize*2;
			g2.drawString(text,  x,  y);
			if(commandNum == 3) {
				g2.drawString(">", x - gp.tileSize, y);
			}
		}
		
	}
	
	public void drawPauseScreen() {
		
		String text = "PAUSED";
		int x = xForCenteredText(text) - (gp.tileSize + 14);
		int y = gp.screenHeight/2 - gp.tileSize;
		g2.setFont(serif_80Win);
		g2.drawString(text, x, y);
	}
	
	public void drawDialogueScreen() {
		// WINDOW
		int x = gp.tileSize * 2;
		int y = gp.tileSize/2;
		int width = gp.screenWidth - (gp.tileSize * 4);
		int height = gp.tileSize*3;
		drawSubWindow(x, y, width, height);
		
		x += gp.tileSize;
		y += gp.tileSize;
		g2.setFont(serif_35);
		
		for(String line : currentDialogue.split("\n")) {
			g2.drawString(line, x, y);
			y += 40;
		}	
	}
	
	public void drawCharacterScreen() {
		
		// CREATE A FRAME
		final int frameX = gp.tileSize;
		final int frameY = gp.tileSize;
		final int frameWidth = gp.tileSize*5;
		final int frameHeight = gp.tileSize*8;
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		// TEXT
		g2.setColor(Color.white);
		g2.setFont(g2.getFont().deriveFont(32F));
		
		int textX = frameX + 20;
		int textY = frameY + gp.tileSize;
		final int lineHeight = 48;
		
		if(characterScreenState == 0) {
		// NAMES
		g2.drawString("Level", textX, textY);
		textY += lineHeight;
		g2.drawString("Life", textX, textY);
		textY += lineHeight;
		g2.drawString("Strength", textX, textY);
		textY += lineHeight;
		g2.drawString("Endurance", textX, textY);
		textY += lineHeight;
		g2.drawString("Attack", textX, textY);
		textY += lineHeight;
		g2.drawString("Defense", textX, textY);
		textY += lineHeight;
		g2.drawString("Exp", textX, textY);
		textY += lineHeight;
		g2.drawString("Next Level", textX, textY);
		textY += lineHeight;
		g2.drawString("Coins", textX, textY);
		textY += lineHeight + 20;
		g2.drawString("Weapon", textX, textY);
		textY += lineHeight + 15;
		g2.drawString("Shield", textX, textY);
		textY += lineHeight;
		
		// VALUES
		int tailX = (frameX + frameWidth) - 30;
		// RESET textY
		textY = frameY + gp.tileSize;
		String value;
		
		value = String.valueOf(gp.player.level);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		if(gp.player.health > 0)
		value = String.valueOf(gp.player.health + "/" + gp.player.maxHealth);
		else
		value = String.valueOf("0/" + gp.player.maxHealth);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.strength);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.endurance);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.attack);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.defense);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.exp);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.nextLvlExp + " exp");
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.coin);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;

		g2.drawImage(gp.player.currentWeapon.down1, tailX - gp.tileSize, textY - 40, null);
		textY += gp.tileSize;
		
		g2.drawImage(gp.player.currentShield.down1, tailX - gp.tileSize, textY - 46, null);
		textY += gp.tileSize;
		
		}
		
		if(characterScreenState == 1) {
		g2.drawString("Magic Level", textX, textY);
		textY += lineHeight;
		
		g2.drawString("Magic Attack", textX, textY);
		textY += lineHeight;
		
		g2.drawString("Magic Defense", textX, textY);
		textY += lineHeight;
		
		int tailX = (frameX + frameWidth) - 30;
		// RESET textY
		textY = frameY + gp.tileSize;
		String value;
			
		value = String.valueOf(gp.player.magicLevel);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.magicAttack);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		
		value = String.valueOf(gp.player.magicDefense);
		textX = xForAlignToRightText(value, tailX);
		g2.drawString(value, textX, textY);
		textY += lineHeight;
		}
	}
	
	public void drawInventory() {
		
		// FRAME
		int frameX = gp.tileSize*9;
		int frameY = gp.tileSize;
		int frameWidth = gp.tileSize*6;
		int frameHeight = gp.tileSize*5;
		drawSubWindow(frameX, frameY, frameWidth, frameHeight);
		
		// SLOTS
		final int slotXstart = frameX + 40;
		final int slotYstart = frameY + 40;
		int slotX = slotXstart;
		int slotY = slotYstart;
		
		// DRAW PLAYER'S ITEMS
		for(int i = 0; i < gp.player.inventory.size(); i++) {
			
			// EQUIP CURSOR
			if(gp.player.inventory.get(i) == gp.player.currentWeapon ||
			   gp.player.inventory.get(i) == gp.player.currentShield) {
				g2.setColor(new Color(240, 190, 90));
				g2.fillRoundRect(slotX, slotY, gp.tileSize, gp.tileSize, 10, 10);
			}
			
			g2.drawImage(gp.player.inventory.get(i).down1, slotX, slotY, null);
			
			slotX += gp.tileSize;
			
			if(i == 4 || i == 9 || i == 14) {
				slotX = slotXstart;
				slotY += gp.tileSize;
			}
		}
		
		// CURSOR
		int cursorX = slotXstart + (gp.tileSize * slotCol);
		int cursorY = slotYstart + (gp.tileSize * slotRow);
		int cursorWidth = gp.tileSize;
		int cursorHeight = gp.tileSize;
		
		// DRAW CURSOR
		g2.setColor(Color.white);
		g2.setStroke(new BasicStroke(3));
		g2.drawRoundRect(cursorX, cursorY, cursorWidth, cursorHeight, 10, 10);
		
		// ITEM DESCRIPTION FRAME
		int dFrameX = frameX;
		int dFrameY = frameY + frameHeight;
		int dFrameWidth = frameWidth;
		int dFrameHeight = gp.tileSize*2;
		
		// ITEM DESCRIPTION TEXT
		int textX = dFrameX + 20;
		int textY = dFrameY + 40;
		g2.setFont(g2.getFont().deriveFont(28F));
		
		int itemIndex = getItemIndexOnSlot();
		
		if(itemIndex < gp.player.inventory.size()) {
			
			drawSubWindow(dFrameX, dFrameY, dFrameWidth, dFrameHeight);
			
			for(String line: gp.player.inventory.get(itemIndex).description.split("\n")) {
				
				g2.drawString(line, textX, textY);
				textY += 40;
			}
		}
	}
	
	public int getItemIndexOnSlot() {
		
		int itemIndex = slotCol + (slotRow*5);
		return itemIndex;
	}
	
	public void drawSubWindow(int x, int y, int width, int height) {
	
		
		Color c = new Color(0, 0, 0, 220);  // Last value is for opacity
		g2.setColor(c);
		g2.fillRoundRect(x,  y, width, height, 35, 35);
		
		c = new Color(255, 255, 255);
		g2.setColor(c);
		g2.setStroke(new BasicStroke (5));
		g2.drawRoundRect(x + 5, y + 5, width - 10, height - 10, 25, 25);
	}
	
	public int xForCenteredText(String text) {
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		return x;
	}
	
	public int xForAlignToRightText(String text, int tailX) {
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = tailX - length;
		return x;
	}
}



