package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.text.DecimalFormat;
import objects.OBJ_key;
import objects.OBJ_boots;

public class UI {

	GamePanel gp;
	Graphics2D g2;
	Font serif_40, serif_80Win;
	//BufferedImage keyImage, bootImage;
	public boolean msgOn = false;
	public String message = "";
	int msgCounter = 0;
	public boolean gameFinished = false;
	double playTime;
	DecimalFormat dFormat = new DecimalFormat("#0.00");
	
	public UI(GamePanel gp) {
		this.gp = gp;
		
		serif_40 = new Font("Serif", Font.BOLD, 40);
		serif_80Win = new Font("Serif", Font.BOLD, 80);
	//	OBJ_key Key = new OBJ_key(gp);
	//	keyImage = Key.image;
	//	OBJ_boots Boots = new OBJ_boots(gp);
	//	bootImage = Boots.image;
	}
	
	public void showMessage(String text) {
		
		message = text;
		msgOn = true;
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		
		g2.setFont(serif_40);
		g2.setColor(Color.white);
		
		if(gp.gameState == gp.playState) {
			// will add later
		}
		if(gp.gameState == gp.pauseState) {
			drawPauseScreen();
		}
	}
	public void drawPauseScreen() {
		
		String text = "PAUSED";
		int x = xForCenteredText(text);
		int y = gp.screenHeight/2;
		g2.drawString(text, x, y);
	}
	public int xForCenteredText(String text) {
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		return x;
	}
}










