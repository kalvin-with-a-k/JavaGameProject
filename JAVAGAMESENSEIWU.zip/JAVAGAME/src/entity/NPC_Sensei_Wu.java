package entity;

import java.util.Random;

import main.GamePanel;

public class NPC_Sensei_Wu extends Entity{

	
	public NPC_Sensei_Wu(GamePanel gp) {
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
	}
	public void getImage() {
	
		up1 = setUp("/npc/senseiBack1");
		up2 = setUp("/npc/senseiBack2");
		down1 = setUp("/npc/senseiFront1");
		down2 = setUp("/npc/senseiFront2");
		left1 = setUp("/npc/senseiLeft1");
		left2 = setUp("/npc/senseiLeft2");
		right1 = setUp("/npc/senseiRight1");
		right2 = setUp("/npc/senseiRight2");
	}
	
	public void setAction() {
		
		movementInterval++;
		
		if(movementInterval == 140) {
		
		Random random = new Random();
		int i = random.nextInt(100)+1; // RNG 1-100
		
		if(i <= 25) {
			direction = "up";
		}
		if(i > 25 && i <= 50) {
			direction = "down";
		}
		if(i > 50 && i <= 75) {
			direction = "left";
		}
		if(i > 75 && i <= 100) {
			direction = "right";
		}
		movementInterval = 0;
		}
	}
}






