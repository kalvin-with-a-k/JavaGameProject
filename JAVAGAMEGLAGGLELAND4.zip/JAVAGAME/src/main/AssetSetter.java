package main;

import entity.NPC_Sensei_Wu;
import monster.MON_GreenSlime;
import objects.OBJ_boots;
import objects.OBJ_chest;
import objects.OBJ_door;
import objects.OBJ_key;
import entity.Entity;

public class AssetSetter {

	GamePanel gp;
	
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	public void setObject() {
		
		gp.obj[0] = new OBJ_door(gp);
		gp.obj[0].worldX = gp.tileSize*22;
		gp.obj[0].worldY = gp.tileSize*22;
		
		gp.obj[1] = new OBJ_door(gp);
		gp.obj[1].worldX = gp.tileSize*20;
		gp.obj[1].worldY = gp.tileSize*20;
	}
	public void setNPC() {
		
		gp.npc[0] = new NPC_Sensei_Wu(gp);
		gp.npc[0].worldX = gp.tileSize*29;
		gp.npc[0].worldY = gp.tileSize*29;
	}
public void setMonster() {
		
		gp.monster[0] = new MON_GreenSlime(gp);
		gp.monster[0].worldX = gp.tileSize*30;
		gp.monster[0].worldY = gp.tileSize*26;
		
		gp.monster[1] = new MON_GreenSlime(gp);
		gp.monster[1].worldX = gp.tileSize*32;
		gp.monster[1].worldY = gp.tileSize*23;
	}
}
