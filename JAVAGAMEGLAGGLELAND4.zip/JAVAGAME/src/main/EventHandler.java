package main;

import java.awt.Rectangle;

public class EventHandler {
	
	GamePanel gp;
	EventRect eventRect[][];
	
	int counter = 0;
	int previousEventX, previousEventY;
	boolean canTouchEvent = true;
	boolean poisoned = false;
	
	public EventHandler(GamePanel gp) {
		this.gp = gp;
		
		eventRect = new EventRect[gp.maxWorldCol][gp.maxWorldRow];
		
		int col = 0;
		int row = 0;
		while(col < gp.maxWorldCol && row < gp.maxWorldRow) {
			
			eventRect[col][row] = new EventRect();
			eventRect[col][row].x = 32;
			eventRect[col][row].y = 32;
			eventRect[col][row].width = 2;
			eventRect[col][row].height = 2;
			eventRect[col][row].eventRectDefaultX = eventRect[col][row].x;
			eventRect[col][row].eventRectDefaultY = eventRect[col][row].y;
			
			col++;
			if(col == gp.maxWorldCol) {
				col = 0;
				row++;
			}
		}
	}
	
	public void checkEvent() {
		
		// Check if player is 1+ tile away from last event toggle
		int distanceX = Math.abs(gp.player.worldX - previousEventX);
		int distanceY = Math.abs(gp.player.worldY - previousEventY);
		int distance = Math.max(distanceX, distanceY);
		if(distance > gp.tileSize) {
			canTouchEvent = true;
		}
		
		if(canTouchEvent == true) {
		
		if(hit(29, 27, "any") == true)
			speedChange(29, 27, gp.dialogueState);
		if(hit(30, 30, "any") == true)
			snakeBite(30, 30, gp.dialogueState);
		if(hit(30, 31, "any") == true) 
			healingGrass(30, 31, gp.dialogueState); 
		if(hit(31, 32, "any") == true)  
			teleport(31, 32, gp.dialogueState);
		}
		
		delayedCheckEvent(120, 3); // POISON GRASS
	}
	
	public void delayedCheckEvent(int stop, int totalHits) {
	    int cooldown = stop / totalHits;

	    if(hit(30, 32, "any") == true ) {
	    	poisoned = true;
	    }
	      
	    if(poisoned == true) {
	    	
	    	if(counter == 0 || counter%cooldown == 0) {
	    	    poisonGrass(gp.dialogueState);	
	    	}
	    	
	    	counter++;
	    	
	    	if(counter >= stop) {
	    		poisoned = !poisoned;
	    		counter = 0;
	    	}
		}
	}
	
	// DIFFERENT HIT EFFECTS
	
	public boolean hit(int col, int row, String reqDirection) {
		boolean hit = false;
		
		gp.player.hitboxArea.x = gp.player.worldX + gp.player.hitboxArea.x;
		gp.player.hitboxArea.y = gp.player.worldY + gp.player.hitboxArea.y;
		eventRect[col][row].x = col*gp.tileSize + eventRect[col][row].x;
		eventRect[col][row].y = row*gp.tileSize + eventRect[col][row].y;
		
		if(gp.player.hitboxArea.intersects(eventRect[col][row]) && eventRect[col][row].eventDone == false) {
			if(gp.player.direction.contentEquals(reqDirection) || reqDirection.contentEquals("any")) { 
				
				hit = true;
				
				previousEventX = gp.player.worldX;
				previousEventY = gp.player.worldY;
			}
		}
		
		// reset hitboxes
		gp.player.hitboxArea.x = gp.player.solidAreaDefaultX;
		gp.player.hitboxArea.y = gp.player.solidAreaDefaultY;
		eventRect[col][row].x = eventRect[col][row].eventRectDefaultX;
		eventRect[col][row].y = eventRect[col][row].eventRectDefaultY;
		
		return hit;
	}

	
	
	// EVENT TILES
	
	public void poisonGrass(int gameState) {
		gp.gameState = gameState;
		gp.ui.currentDialogue = "Poisonous grass. Yuck.";
		damage(1);
		canTouchEvent = false;
	}
	
	public void snakeBite(int col, int row, int gameState) {
		gp.gameState = gameState;
		gp.ui.currentDialogue = "AHH!! SNAKE!!!";
		damage(2);
		eventRect[col][row].eventDone = true;
	}
	
	public void healingGrass(int col, int row, int gameState) {
		if(gp.keyH.enterPress == true) {
			gp.gameState = gameState;
			gp.ui.currentDialogue = "Mmmm. Heals.";
			heal(6);
			canTouchEvent = false;
		}
	}
	
	public void teleport(int col, int row, int gameState) {
		gp.gameState = gameState;
		gp.player.worldX = gp.tileSize*28;
		gp.player.worldY = gp.tileSize*28;
		gp.ui.currentDialogue = "What the..?!";
	}
	
	public void speedChange(int col, int row, int gameState) {
		gp.gameState = gameState;
		gp.ui.currentDialogue = "SPEEEEEEED!!!!!";
		speed(3);
		canTouchEvent = false;
	}
	
	
	// PLAYER EFFECTS
	
	public void damage(int damage) {
		if(gp.player.health > 0) 
		gp.player.health -= damage;
	}
	
	public void heal(int heal) {
		if(gp.player.health + heal <= 6) 
		gp.player.health += heal;
		else
		gp.player.health = gp.player.maxHealth;
	}
	
	public void speed(int speed) {
		gp.player.speed += speed;
	}
}





