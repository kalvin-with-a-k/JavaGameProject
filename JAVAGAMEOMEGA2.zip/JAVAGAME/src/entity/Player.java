package entity;

import main.KeyHandler;
import main.UtilityToolbox;
import objects.OBJ_Basic_Shield;
import objects.OBJ_Basic_Sword;
import objects.OBJ_Wooden_Staff;
import objects.OBJ_key;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import main.GamePanel;
 
public class Player extends Entity{

	KeyHandler keyH;
	public final int screenX;
	public final int screenY;
	int standCounter = 0;
	public boolean attackCancelled = false;
	public ArrayList<Entity> inventory = new ArrayList<>();
	public final int inventorySize = 20;
		
	public Player(GamePanel gp, KeyHandler keyH) {
		
		super(gp);
		
		this.keyH = keyH;
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		hitboxArea = new Rectangle();
		hitboxArea.x = 20;
		hitboxArea.y = 22;
		solidAreaDefaultX = hitboxArea.x;
		solidAreaDefaultY = hitboxArea.y;
		hitboxArea.width = 38 ;
		hitboxArea.height = 42;
		
		attackHitbox.width = 34;
		attackHitbox.height = 34;
		
		setDefaultValues();
		getPlayerImage();
		getPlayerAttackImage();
		setItems();
	}
	public void setDefaultValues() {
		
		worldX = gp.tileSize * 25;
		worldY = gp.tileSize * 25;
		speed = 5;
		direction = "down";
		
		// PLAYER HEALTH
		level = 1;
		maxHealth = 6;
		health = maxHealth;
		strength = 1;		// INCREASES DAMAGE
		endurance = 1;		// INCREASES DEFENSE
		exp = 0;
		nextLvlExp = 2;
		magicLevel = 1;
		//offensiveMana = 1;
		//defensiveMana = 1;
		coin = 0;
		currentWeapon = new OBJ_Wooden_Staff(gp);
		currentShield = new OBJ_Basic_Shield(gp);
		attack = getAttack();
		defense = getDefense();
		magicAttack = getMagicAttack();
		magicDefense = getMagicDefense();
	}
	
	public void setItems() {
		
		inventory.add(currentWeapon);
		inventory.add(currentShield);
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
		inventory.add(new OBJ_key(gp));
	}
	
	public int getAttack() {
		return attack = strength * currentWeapon.attackValue;
	}
	public int getDefense() {
		return defense = endurance * currentShield.defenseValue;
	}
	public int getMagicAttack() {
		return magicAttack = (currentWeapon.magicAttackValue + magicLevel)*2;
	}
	public int getMagicDefense() {
		return magicDefense = (currentShield.magicDefenseValue + magicLevel)*2;
	}
	
	public void getPlayerImage() {	
		up1 = setUp("/player/sprite1Back", gp.tileSize, gp.tileSize);
		up2 = setUp("/player/sprite2Back", gp.tileSize, gp.tileSize);
		down1 = setUp("/player/sprite1Front", gp.tileSize, gp.tileSize);
		down2 = setUp("/player/sprite2Front", gp.tileSize, gp.tileSize);
		left1 = setUp("/player/sprite1Left", gp.tileSize, gp.tileSize);
		left2 = setUp("/player/sprite2Left", gp.tileSize, gp.tileSize);
		right1 = setUp("/player/sprite1Right", gp.tileSize, gp.tileSize);
		right2 = setUp("/player/sprite2Right", gp.tileSize, gp.tileSize);
		
		redUp1 = setUp("/player/red1Back", gp.tileSize, gp.tileSize);
		redUp2 = setUp("/player/red2Back", gp.tileSize, gp.tileSize);
		redDown1 = setUp("/player/red1Front", gp.tileSize, gp.tileSize);
		redDown2 = setUp("/player/red2Front", gp.tileSize, gp.tileSize);
		redLeft1 = setUp("/player/red1Left", gp.tileSize, gp.tileSize);
		redLeft2 = setUp("/player/red2Left", gp.tileSize, gp.tileSize);
		redRight1 = setUp("/player/red1Right", gp.tileSize, gp.tileSize);
		redRight2 = setUp("/player/red2Right", gp.tileSize, gp.tileSize);
		
		rikaUp1 = setUp("/player/rikaBack1", gp.tileSize, gp.tileSize);
		rikaUp2 = setUp("/player/rikaBack2", gp.tileSize, gp.tileSize);
		rikaDown1 = setUp("/player/rikaFront1", gp.tileSize, gp.tileSize);
		rikaDown2 = setUp("/player/rikaFront2", gp.tileSize, gp.tileSize);
		rikaLeft1 = setUp("/player/rikaLeft1", gp.tileSize, gp.tileSize);
		rikaLeft2 = setUp("/player/rikaLeft2", gp.tileSize, gp.tileSize);
		rikaRight1 = setUp("/player/rikaRight1", gp.tileSize, gp.tileSize);
		rikaRight2 = setUp("/player/rikaRight2", gp.tileSize, gp.tileSize);
	}
	
	public void getPlayerAttackImage() {
		
		gbpAtkUp1 = setUp("/player/gbpAtkUp1", gp.tileSize, gp.tileSize*2);
		gbpAtkUp2 = setUp("/player/gbpAtkUp2", gp.tileSize, gp.tileSize*2);
		gbpExpAtkUp3 = setUp("/player/gbpExpAtkUp3", gp.tileSize, gp.tileSize*2);
		gbpExpAtkUp4 = setUp("/player/gbpExpAtkUp4", gp.tileSize, gp.tileSize*2);
		gbpExpAtkUp5 = setUp("/player/gbpExpAtkUp5", gp.tileSize, gp.tileSize*2);
	
		gbpAtkDown1 = setUp("/player/gbpAtkDown1", gp.tileSize, gp.tileSize*2);
		gbpAtkDown2 = setUp("/player/gbpAtkDown2", gp.tileSize, gp.tileSize*2);
		gbpExpAtkDown3 = setUp("/player/gbpExpAtkDown3", gp.tileSize, gp.tileSize*2);
		gbpExpAtkDown4 = setUp("/player/gbpExpAtkDown4", gp.tileSize, gp.tileSize*2);
		gbpExpAtkDown5 = setUp("/player/gbpExpAtkDown5", gp.tileSize, gp.tileSize*2);
	
		gbpAtkLeft1 = setUp("/player/gbpAtkLeft1", gp.tileSize*2, gp.tileSize);
		gbpAtkLeft2 = setUp("/player/gbpAtkLeft2", gp.tileSize*2, gp.tileSize);
		gbpExpAtkLeft3 = setUp("/player/gbpExpAtkLeft3", gp.tileSize*2, gp.tileSize);
		gbpExpAtkLeft4 = setUp("/player/gbpExpAtkLeft4", gp.tileSize*2, gp.tileSize);
		gbpExpAtkLeft5 = setUp("/player/gbpExpAtkLeft5", gp.tileSize*2, gp.tileSize);
	
		gbpAtkRight1 = setUp("/player/gbpAtkRight1", gp.tileSize*2, gp.tileSize);
		gbpAtkRight2 = setUp("/player/gbpAtkRight2", gp.tileSize*2, gp.tileSize);
		gbpExpAtkRight3 = setUp("/player/gbpExpAtkRight3", gp.tileSize*2, gp.tileSize);
		gbpExpAtkRight4 = setUp("/player/gbpExpAtkRight4", gp.tileSize*2, gp.tileSize);
		gbpExpAtkRight5 = setUp("/player/gbpExpAtkRight5", gp.tileSize*2, gp.tileSize);
	}
	
	public void update() {
		
		if(specialAttack == true) {
			specialAttack();
		} else if(basicAttack == true) {
			basicAttack();
		}
		
		else if(keyH.upPress == true || keyH.downPress == true || keyH.leftPress == true || keyH.rightPress == true || 
				keyH.enterPress == true || keyH.ePress) {
		
			if(keyH.upPress == true) 
				direction = "up";
			else if(keyH.downPress == true) 
				direction = "down";
			else if(keyH.leftPress == true) 
				direction = "left";
			else if(keyH.rightPress == true) 
				direction = "right";
		
		// CHECK TILE COLLISION
		collisionOn = false;
		gp.cChecker.checkTile(this);
		
		// CHECK OBJECT COLLISION
		int objIndex = gp.cChecker.checkObject(this,  true);
		pickUpObject(objIndex);
		
		// CHECK NPC COLLISION
		int npcIndex = gp.cChecker.checkEntity(this, gp.npc);
		interactNPC(npcIndex);
		
		// CHECK MONSTER COLLISION
		int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
		contactMonster(monsterIndex);
		
		// CHECK EVENT
		gp.eHandler.checkEvent();
	
		// 	IF COLLISION IS FALSE, PLAYER CAN MOVE
		if(collisionOn == false && keyH.enterPress == false && specialAttack == false) {
			
			switch(direction) {
				case "up": worldY -= speed;
					break;
				case"down": worldY += speed;
					break;
				case"left": worldX -= speed;
					break;
				case"right": worldX += speed;
					break;
			}
		}	
		
		if(keyH.enterPress == true && attackCancelled == false) {
			gp.playSFX(5);
			basicAttack = true;
			spriteCounter = 0;
		}
	    if(keyH.ePress == true && attackCancelled == false) {
			gp.playSFX(7);
			specialAttack = true;
			spriteCounter = 0;
		}
		
		attackCancelled = false;
		gp.keyH.enterPress = false;
		
		spriteCounter++;
		if(spriteCounter > 12) {
			if(spriteNum == 1) 
				spriteNum = 2;
			else if(spriteNum == 2) 
				spriteNum = 1;
			
			spriteCounter = 0;
		}
	}
		else {  standCounter++;
			if(standCounter == 20) {
				spriteNum = 1;
				standCounter = 0; 			// 20 frame buffer for idle stand position
			}
		}
	
		if(invincible == true) {
		invincibleCounter++;
			if(invincibleCounter > 60) {
				invincible = false;
				invincibleCounter = 0;
			}
		}
	}
	
	public void basicAttack() {
		
		spriteCounter++;
		
		if(spriteCounter <= 15)
			spriteNum = 1;
		if(spriteCounter > 15 && spriteCounter <= 35) 
			spriteNum = 2;
		
		// SAVE CURRENT WORLDX, WORLDY, HITBOX AREA
		int currentWorldX = worldX;
		int currentWorldY = worldY;
		int hitboxAreaWidth = hitboxArea.width;
		int hitboxAreaHeight = hitboxArea.height;
		
		// ADJUST PLAYER'S WORLDX/Y FOR ATTACK HITBOX
		switch(direction) {
		case "up": worldY -= attackHitbox.height; break;
		case "down": worldY += gp.tileSize; break;
		case "left": worldX -= attackHitbox.width; break;
		case "right": worldX += gp.tileSize; break;
		}
		
		// ATTACK HITBOX BECOMES HITBOX
		hitboxArea.width = attackHitbox.width;
		hitboxArea.height = attackHitbox.height;
		
		// CHECK MONSTER COLLISION W/ UPDATED WORLDX/Y & HITBOX
		int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
		damageMonster(monsterIndex);
		
		// RESTORE ORIGINAL DATA
		worldX = currentWorldX;
		worldY = currentWorldY;
		hitboxArea.width = hitboxAreaWidth;
		hitboxArea.height = hitboxAreaHeight;
		
		if(spriteCounter > 35) {
			spriteNum = 1;
			spriteCounter = 0;
			basicAttack = false;
		}
	}

	public void specialAttack() {
		
		spriteCounter++;
		
		if(spriteCounter <= 15)
			spriteNum = 1;
		if(spriteCounter > 15 && spriteCounter <= 25) 
			spriteNum = 2;
		if(spriteCounter > 25 && spriteCounter <= 35)
			spriteNum = 3;
		
		// SAVE CURRENT WORLDX, WORLDY, HITBOX AREA
		
		attackHitbox.width = 40;
		attackHitbox.height = 40;
		
		int currentWorldX = worldX;
		int currentWorldY = worldY;
		int hitboxAreaWidth = hitboxArea.width;
		int hitboxAreaHeight = hitboxArea.height;
					
		// ADJUST PLAYER'S WORLDX/Y FOR ATTACK HITBOX
				
		switch(direction) {
		case "up": worldY -= (attackHitbox.height + 15); break;
		case "down": worldY += (gp.tileSize + 15); break;
		case "left": worldX -= (attackHitbox.width + 15); break;
		case "right": worldX += (gp.tileSize + 15); break;
		}
						
		// ATTACK HITBOX BECOMES HITBOX
		hitboxArea.width = attackHitbox.width;	
		hitboxArea.height = attackHitbox.height;
					
		// CHECK MONSTER COLLISION W/ UPDATED WORLDX/Y & HITBOX
		int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
		damageMonster(monsterIndex);
					
		// RESTORE ORIGINAL DATA
		worldX = currentWorldX;
		worldY = currentWorldY;
		hitboxArea.width = hitboxAreaWidth;
		hitboxArea.height = hitboxAreaHeight;
					
		if(spriteCounter > 35 && spriteCounter <= 45)
			spriteNum = 4;
		if(spriteCounter > 45 && spriteCounter <= 85)
			spriteNum = 5;
		if(spriteCounter > 85) {
			spriteNum = 1;
			spriteCounter = 0;
			specialAttack = false;
			gp.keyH.ePress = false;		
		}
	}
	
	public void pickUpObject(int i) {
		if(i != 999) {
		}
	}
	
	public void interactNPC(int i) {
		
		if(gp.keyH.enterPress == true) {
			
			if(i != 999) {
				attackCancelled = true;
				gp.gameState = gp.dialogueState;
				gp.npc[i].speak();			
			}
		}
	}
	
	public void contactMonster(int i) {
		
		if( i != 999) {
			
			if(invincible == false) {
				gp.playSFX(6);
				int damage = gp.monster[i].attack - defense;
				if(damage < 0) {
					damage = 0;
				}
				health -= damage;
				invincible = true;
			}
		}
	}
	
	public void damageMonster(int i) {
		
		if(i != 999) {
			
			if(gp.monster[i].invincible == false) {
				
				if(specialAttack == true) {
					int damage = magicAttack - gp.monster[i].magicDefense;
					if(damage < 0) {
						damage = 0;
					}
					gp.monster[i].health -= damage;
					gp.ui.addMessage(damage+ " damage!");
					gp.monster[i].invincible = true;
					gp.monster[i].damageReaction();
				}
				if(basicAttack == true) {
					int damage = attack - gp.monster[i].defense;
					if(damage < 0) {
						damage = 0;
					}
					gp.monster[i].health -= damage;
					gp.ui.addMessage(damage+ " damage!");
					
					gp.monster[i].invincible = true;
					gp.monster[i].damageReaction();
				}
				if(gp.monster[i].health <= 0) {
					gp.monster[i].dying = true;
					gp.ui.addMessage("killed the " + gp.monster[i].name + "!");
					gp.ui.addMessage("Exp + " + gp.monster[i].exp);
					exp += gp.monster[i].exp;
					checkLevelUp();
				}
			}
		}
	}
	
	public void checkLevelUp() {
		if(exp >= nextLvlExp) {
			level++;
			exp = 0;
			nextLvlExp = nextLvlExp*2 - 1;
			strength ++;
			attack = getAttack();
			defense = getDefense();
			
			if(level % 2 == 0) {
			maxHealth += 2;
			health += 2;
			endurance ++;
			} 
			if(level % 3 == 0) {
			magicLevel++;
			magicAttack = getMagicAttack();
            magicDefense = getMagicDefense();
			} 			
			
			gp.playSFX(8);
			gp.gameState = gp.dialogueState;
			gp.ui.currentDialogue = "You are now level " + level + "!\n"
								     + "You feel an odd surge of power...";
		}
	}

	
	public void draw(Graphics2D g2) {
		
		BufferedImage image = null;
		int tempScreenX = screenX;
		int tempScreenY = screenY;
		
		if(gp.ui.titleScreenState == 1 && gp.ui.commandNum == 0) {
		
		switch(direction) {
		case "up":
			if(basicAttack == false || specialAttack == false) {
				if(spriteNum == 1) image = up1;
				if(spriteNum == 2) image = up2;
			}
			if(basicAttack == true || specialAttack == true) {
				tempScreenY = screenY - gp.tileSize;
				if(spriteNum == 1) image = gbpAtkUp1;
				if(spriteNum == 2) image = gbpAtkUp2;
				if(spriteNum == 3) image = gbpExpAtkUp3;
				if(spriteNum == 4) image = gbpExpAtkUp4;
				if(spriteNum == 5) image = gbpExpAtkUp5;
			}
			break;
		case "down":
			if(basicAttack == false || specialAttack == false) {
				if(spriteNum == 1) image = down1;
				if(spriteNum == 2) image = down2;
			}
			if(basicAttack == true || specialAttack == true) {
				if(spriteNum == 1) image = gbpAtkDown1;
				if(spriteNum == 2) image = gbpAtkDown2;
				if(spriteNum == 3) image = gbpExpAtkDown3;
				if(spriteNum == 4) image = gbpExpAtkDown4;
				if(spriteNum == 5) image = gbpExpAtkDown5;
			}
			break;
		case "left":
			if(basicAttack == false || specialAttack == false) {
				if(spriteNum == 1) image = left1;
				if(spriteNum == 2) image = left2;
			}
			if(basicAttack == true || specialAttack == true) {
				tempScreenX = screenX - gp.tileSize;
				if(spriteNum == 1) image = gbpAtkLeft1;
				if(spriteNum == 2) image = gbpAtkLeft2;
				if(spriteNum == 3) image = gbpExpAtkLeft3;
				if(spriteNum == 4) image = gbpExpAtkLeft4;
				if(spriteNum == 5) image = gbpExpAtkLeft5;
			}
			break;
		case "right":
			if(basicAttack == false || specialAttack == false) {
				if(spriteNum == 1) image = right1;
				if(spriteNum == 2) image = right2;
			}
			if(basicAttack == true || specialAttack == true) {
				if(spriteNum == 1) image = gbpAtkRight1;
				if(spriteNum == 2) image = gbpAtkRight2;
				if(spriteNum == 3) image = gbpExpAtkRight3;
				if(spriteNum == 4) image = gbpExpAtkRight4;
				if(spriteNum == 5) image = gbpExpAtkRight5;
			}
			break;
			}
		
		}else if(gp.ui.titleScreenState == 1 && gp.ui.commandNum == 1) {
			
			switch(direction) {
			case "up":
				if(spriteNum == 1) image = rikaUp1;
				if(spriteNum == 2) image = rikaUp2;
				break;
			case "down":
				if(spriteNum == 1) image = rikaDown1;
				if(spriteNum == 2) image = rikaDown2;
				break;
			case "left":
				if(spriteNum == 1) image = rikaLeft1;
				if(spriteNum == 2) image = rikaLeft2;
				break;
			case "right":
				if(spriteNum == 1) image = rikaRight1;
				if(spriteNum == 2) image = rikaRight2;
				break;
				}
			
		}else if(gp.ui.titleScreenState == 1 && gp.ui.commandNum == 2) {
			
			switch(direction) {
			case "up":
				if(spriteNum == 1) image = redUp1;
				if(spriteNum == 2) image = redUp2;
				break;
			case "down":
				if(spriteNum == 1)image = redDown1;
				if(spriteNum == 2) image = redDown2;
				break;
			case "left":
				if(spriteNum == 1) image = redLeft1;
				if(spriteNum == 2) image = redLeft2;
				break;
			case "right":
				if(spriteNum == 1) image = redRight1;
				if(spriteNum == 2) image = redRight2;
				break;
				}
			
			}
		
		if(invincible == true) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		}

		g2.drawImage(image, tempScreenX, tempScreenY, null);
		
		//Reset alpha
		if(invincible == true) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		}
		
		if(keyH.toggleDebug == true) { // DEBUG
			
		// SHOW HITBOX
		g2.setColor(Color.red); 
		g2.drawRect(screenX + hitboxArea.x, screenY + hitboxArea.y, hitboxArea.width, hitboxArea.height);
		g2.setFont(new Font("Arial", Font.PLAIN, 26));
		g2.setColor(Color.white);
		g2.drawString("Invincible Frames: " + invincibleCounter, 10, 400);
		
		// BASIC ATTACK HITBOX	
		
		tempScreenX = screenX + hitboxArea.x;
		tempScreenY = screenY + hitboxArea.y;
		switch(direction) {
		case "up": tempScreenY = screenY - attackHitbox.height;
		break;
		case "down": tempScreenY = screenY + gp.tileSize;
		break;
		case "left": tempScreenX = screenX - attackHitbox.width;
		break;
		case "right": tempScreenX = screenX + gp.tileSize;
		break;
		}
		g2.setColor(Color.red);
		g2.setStroke(new BasicStroke(1));
		g2.drawRect(tempScreenX, tempScreenY, attackHitbox.width, attackHitbox.height);
		
		// SPECIAL ATTACK HITBOX	
		tempScreenX = screenX + hitboxArea.x;
		tempScreenY = screenY + hitboxArea.y;
		switch(direction) {
		case "up": tempScreenY = screenY - (attackHitbox.height + 15);
		break;
		case "down": tempScreenY = screenY + (gp.tileSize + 15);
		break;
		case "left": tempScreenX = screenX - (attackHitbox.width + 15);
		break;
		case "right": tempScreenX = screenX + (gp.tileSize + 15);
		break;
		}
		g2.setColor(Color.blue);
		g2.setStroke(new BasicStroke(1));
		g2.drawRect(tempScreenX, tempScreenY, attackHitbox.width, attackHitbox.height);
		}
	}
}












