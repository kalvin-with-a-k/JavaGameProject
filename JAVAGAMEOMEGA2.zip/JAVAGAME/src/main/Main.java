package main;
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {

		JFrame window = new JFrame();
		GamePanel gamePanel = new GamePanel();
		 
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		window.setResizable(false);
		window.setTitle("2D Adventure");
		
		window.add(gamePanel);
		window.pack(); //resizes window to fit preferred size/layouts of its subcomponents (=GamePanel)
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		gamePanel.gameSetUp();
		gamePanel.startGameThread();
		
	}   

}
