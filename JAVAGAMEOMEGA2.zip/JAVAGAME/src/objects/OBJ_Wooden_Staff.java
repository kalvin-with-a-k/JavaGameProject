package objects;

import entity.Entity;
import main.GamePanel;

public class OBJ_Wooden_Staff extends Entity{
	
	public OBJ_Wooden_Staff(GamePanel gp) {
		
		super(gp);
		
		name = "Wooden Staff";
		down1  = setUp("/objects/woodenStaff", gp.tileSize, gp.tileSize);
		
		attackValue = 2;
		magicAttackValue = 1;
		description = "[" + name + "]\n Well, we all start somewhere!";
	}
}

