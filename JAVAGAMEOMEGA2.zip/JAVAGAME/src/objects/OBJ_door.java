package objects;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_door extends Entity{

	public OBJ_door(GamePanel gp) {
		
		super(gp);
		
		name = "Door";
		down1  = setUp("/objects/door", gp.tileSize, gp.tileSize);
		collision = true;
		
		hitboxArea.x = 0;
		hitboxArea.y = 16;
		hitboxArea.width = 48;
		hitboxArea.height = 32;
		solidAreaDefaultX = hitboxArea.x;
		solidAreaDefaultY = hitboxArea.y;
	}
}
