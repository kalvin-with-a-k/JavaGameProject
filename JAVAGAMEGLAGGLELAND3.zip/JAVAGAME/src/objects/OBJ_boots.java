package objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class OBJ_boots extends SuperObject{
 
	GamePanel gp;
	
	public OBJ_boots(GamePanel gp) {
		
		this.gp = gp;
		
		name = "Boots";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/boot.png"));
			image = uTool.scaledImage(image,  gp.tileSize, gp.tileSize);
			
		}catch(IOException e) {
			e.printStackTrace();		
		}
	}
}

