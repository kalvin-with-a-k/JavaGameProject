package objects;

import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class OBJ_Heart extends SuperObject{
	
GamePanel gp;
	
	public OBJ_Heart(GamePanel gp) {
		
		this.gp = gp;
		
		name = "Heart";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/fullHeart.png"));
			image2= ImageIO.read(getClass().getResourceAsStream("/objects/halfHeart.png"));
			image3 = ImageIO.read(getClass().getResourceAsStream("/objects/blankHeart.png"));
			image = uTool.scaledImage(image,  gp.tileSize - 12, gp.tileSize - 12);
			image2 = uTool.scaledImage(image2,  gp.tileSize - 12, gp.tileSize - 12);
			image3 = uTool.scaledImage(image3,  gp.tileSize - 12, gp.tileSize - 12);
			
		}catch(IOException e) {
			e.printStackTrace();		}
		
	}
}
