package entity;

import java.awt.Rectangle;
import java.util.Random;

import main.GamePanel;

public class NPC_Sensei_Wu extends Entity{

	
	public NPC_Sensei_Wu(GamePanel gp) {
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
		setDialogue();
	}
	public void getImage() {
	
		up1 = setUp("/npc/senseiBack1");
		up2 = setUp("/npc/senseiBack2");
		down1 = setUp("/npc/senseiFront1");
		down2 = setUp("/npc/senseiFront2");
		left1 = setUp("/npc/senseiLeft1");
		left2 = setUp("/npc/senseiLeft2");
		right1 = setUp("/npc/senseiRight1");
		right2 = setUp("/npc/senseiRight2");
	}
	
	public void setDialogue() {
		
		dialogues[0] = "Long ago, in Ancient Glaggleland...";
		dialogues[1] = "...There was a man named The Giggler.";
		dialogues[2] = "The Giggler was a valiant leader respected by the \nglaggles of Glaggleland, a hero who slayed every \nadversary in his path.";
		dialogues[3] = "That was, until December 1202, amidst the harshest \nwinter season yet...";
		dialogues[4] = "...a villain by the name of Enphoso would assassinate \nThe Giggler with baffling ease.";
		dialogues[5] = "Ever since then, Glaggleland has remained a shell of \nits former glory, a fragment of the great nation it once \nwas.";
		dialogues[6] = "--Ah, I'm getting rather sentimental now. Perhaps it's \nbetter if I keep quiet now.";
		dialogues[7] = "......Unless...";
		dialogues[8] = "...Unless you're the prophesized savior of our fallen \ncountry.";
	}
	
	public void setAction() {
		
		movementInterval++;
		
		if(movementInterval == 140) {
		
		Random random = new Random();
		int i = random.nextInt(100)+1; // RNG 1-100
		
		if(i <= 25) {
			direction = "up";
		}
		if(i > 25 && i <= 50) {
			direction = "down";
		}
		if(i > 50 && i <= 75) {
			direction = "left";
		}
		if(i > 75 && i <= 100) {
			direction = "right";
		}
		movementInterval = 0;
		}
	}
	
	public void speak() {
		
		// Character-Specific actions when speaking goes here
		
		super.speak();
	}
}






