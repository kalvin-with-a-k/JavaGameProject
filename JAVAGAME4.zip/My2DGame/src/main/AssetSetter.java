package main;

import objects.OBJ_chest;
import objects.OBJ_door;
import objects.OBJ_key;

public class AssetSetter {

	GamePanel gp;
	
	public AssetSetter(GamePanel gp) {
		this.gp = gp;
	}
	public void setObject() {
		
		gp.obj[0] = new OBJ_key();
		gp.obj[0].worldX = (16 - 1) * gp.tileSize;
		gp.obj[0].worldY = (6 - 1) * gp.tileSize;
		
		gp.obj[1] = new OBJ_key();
		gp.obj[1].worldX = (14 - 1) * gp.tileSize;
		gp.obj[1].worldY = (10 - 1)* gp.tileSize;
		
		gp.obj[2] = new OBJ_door();
		gp.obj[2].worldX = (3 - 1) * gp.tileSize;
		gp.obj[2].worldY = (10 - 1) * gp.tileSize;
		
		gp.obj[3] = new OBJ_door();
		gp.obj[3].worldX = (4 - 1) * gp.tileSize;
		gp.obj[3].worldY = (10 - 1) * gp.tileSize;
		
		gp.obj[4] = new OBJ_door();
		gp.obj[4].worldX = (5 - 1) * gp.tileSize;
		gp.obj[4].worldY = (10 - 1) * gp.tileSize;
		
		gp.obj[5] = new OBJ_chest();
		gp.obj[5].worldX = (30 - 1) * gp.tileSize;
		gp.obj[5].worldY = (6 - 1) * gp.tileSize;
		
	}
}
